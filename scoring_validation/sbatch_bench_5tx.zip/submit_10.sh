#!/bin/bash
set -euo pipefail

# Submit sbatch files in chunks of 10.
# Usage:
#   bash sbatch_bench_5tx/submit_10.sh 1   # submits 1..10
#   bash sbatch_bench_5tx/submit_10.sh 2   # submits 11..20
#   bash sbatch_bench_5tx/submit_10.sh 3   # ...

CHUNK="${1:-1}"
if ! [[ "$CHUNK" =~ ^[0-9]+$ ]]; then
  echo "ERROR: chunk must be an integer (got: $CHUNK)" >&2
  exit 2
fi

mapfile -t FILES < <(ls -1 "/fs/scratch/PAS1755/Pablo/SIREN/siren17/sbatch_bench_5tx"/*.sbatch 2>/dev/null | sort)
TOTAL="${#FILES[@]}"

if [[ "$TOTAL" -eq 0 ]]; then
  echo "No .sbatch files found in /fs/scratch/PAS1755/Pablo/SIREN/siren17/sbatch_bench_5tx" >&2
  exit 1
fi

START=$(( (CHUNK - 1) * 10 ))
END=$(( START + 10 - 1 ))

echo "Found $TOTAL sbatch files."
echo "Submitting chunk $CHUNK: indices $START..$END"
echo

for i in $(seq "$START" "$END"); do
  if [[ "$i" -ge "$TOTAL" ]]; then
    break
  fi
  f="${FILES[$i]}"
  echo "sbatch $f"
  sbatch "$f"
done
